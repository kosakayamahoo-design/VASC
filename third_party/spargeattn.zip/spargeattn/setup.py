"""Build the FP16 sparse runtime used by VASC on Ampere/Ada GPUs."""
import os
from pathlib import Path

from setuptools import find_packages, setup
import torch
from torch.utils.cpp_extension import BuildExtension, CUDAExtension

ROOT = Path(__file__).resolve().parent
os.chdir(ROOT)
archs = os.environ.get("TORCH_CUDA_ARCH_LIST", "8.6;8.9").replace(" ", ";").split(";")
if not archs or any(x not in {"8.6", "8.9"} for x in archs):
    raise RuntimeError("This release build targets 8.6 (A6000) and 8.9 (RTX 4090)")
abi = int(torch._C._GLIBCXX_USE_CXX11_ABI)
common = ["-O3", "-std=c++17", f"-D_GLIBCXX_USE_CXX11_ABI={abi}"]
cuda = common + ["-U__CUDA_NO_HALF_OPERATORS__", "-U__CUDA_NO_HALF_CONVERSIONS__",
                 "--use_fast_math", "--threads=8"]
for arch in archs:
    digits = arch.replace(".", "")
    cuda += ["-gencode", f"arch=compute_{digits},code=sm_{digits}"]
sources = ["csrc/qattn/pybind.cpp", "csrc/qattn/qk_int_sv_f16_cuda_sm80.cu"]
sources += [str(p.relative_to(ROOT)) for p in sorted((ROOT / "csrc/qattn/instantiations_sm80").glob("*.cu"))]
setup(
    name="vasc-sparse-runtime", version="0.1.0", packages=find_packages(),
    ext_modules=[
        CUDAExtension("spas_sage_attn._qattn", sources,
                      extra_compile_args={"cxx": common, "nvcc": cuda}, extra_link_args=["-lcuda"]),
        CUDAExtension("spas_sage_attn._fused", ["csrc/fused/pybind.cpp", "csrc/fused/fused.cu"],
                      extra_compile_args={"cxx": common + ["-fopenmp", "-lgomp", "-DENABLE_BF16"], "nvcc": cuda}),
    ],
    cmdclass={"build_ext": BuildExtension},
)
