#include <pybind11/pybind11.h>

#include "attn_cuda.h"

PYBIND11_MODULE(TORCH_EXTENSION_NAME, m)
{
  m.def(
    "qk_int8_sv_f16_accum_f16_block_sparse_attn_inst_buf_with_pv_threshold",
    &qk_int8_sv_f16_accum_f16_block_sparse_attn_inst_buf_with_pv_threshold);
  m.def(
    "qk_int8_sv_f16_accum_f16_block_sparse_attn_inst_buf",
    &qk_int8_sv_f16_accum_f16_block_sparse_attn_inst_buf);
}
